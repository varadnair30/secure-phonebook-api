from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
import sqlite3
import re
import logging
from datetime import datetime

app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = "your_secret_key"  # Replace with a secure key
jwt = JWTManager(app)

# Regular expressions
NAME_REGEX = r"^([A-Za-z]+(?: [A-Za-z]+)*|[A-Za-z]+, [A-Za-z]+(?: [A-Za-z]+)?)$"
PHONE_REGEX = r"^(\+?[0-9]+[ .-]?)?(\(?[0-9]{2,4}\)?[ .-]?)?[0-9]{3,8}([ .-][0-9]{3,8})?$"

# Database setup
DB_FILE = 'phonebook.db'


def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS phonebook (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT NOT NULL
        )
        """)
    conn.close()


# Logging setup
logging.basicConfig(filename='logs/audit.log', level=logging.INFO)


@app.route('/auth', methods=['POST'])
def authenticate():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    # Hardcoded for simplicity
    if username == "user" and password == "password":
        token = create_access_token(identity=username)
        return jsonify({"token": token}), 200

    return jsonify({"error": "Invalid credentials"}), 401


@app.route('/PhoneBook/list', methods=['GET'])
@jwt_required()
def list_entries():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name, phone FROM phonebook")
        entries = cursor.fetchall()
    return jsonify(entries), 200


@app.route('/PhoneBook/add', methods=['POST'])
@jwt_required()
def add_entry():
    data = request.get_json()
    name = data.get('name')
    phone = data.get('phone')

    if not re.match(NAME_REGEX, name):
        return jsonify({"error": "Invalid name format"}), 400
    if not re.match(PHONE_REGEX, phone):
        return jsonify({"error": "Invalid phone number format"}), 400

    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO phonebook (name, phone) VALUES (?, ?)", (name, phone))
        conn.commit()
    return jsonify({"message": "Entry added successfully"}), 200


@app.route('/PhoneBook/deleteByName', methods=['PUT'])
@jwt_required()
def delete_by_name():
    data = request.get_json()
    name = data.get('name')

    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM phonebook WHERE name = ?", (name,))
        conn.commit()

    if cursor.rowcount == 0:
        return jsonify({"error": "Name not found"}), 404

    return jsonify({"message": "Entry deleted successfully"}), 200


@app.route('/PhoneBook/deleteByNumber', methods=['PUT'])
@jwt_required()
def delete_by_number():
    data = request.get_json()
    phone = data.get('phone')

    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM phonebook WHERE phone = ?", (phone,))
        conn.commit()

    if cursor.rowcount == 0:
        return jsonify({"error": "Phone number not found"}), 404

    return jsonify({"message": "Entry deleted successfully"}), 200


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000)
